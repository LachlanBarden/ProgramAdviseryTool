export function expectation(passed) {
  return passed ? 'not to have' : 'to have';
}
