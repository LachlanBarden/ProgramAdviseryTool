import AbstractPlugin from './AbstractPlugin';

export default AbstractPlugin;
