import Mirror, {defaultOptions} from './Mirror';

export default Mirror;
export {defaultOptions};
