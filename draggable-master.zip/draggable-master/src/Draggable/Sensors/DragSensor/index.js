import DragSensor from './DragSensor';

export default DragSensor;
