select * FROM Major

INSERT INTO Major (
	MajorID,
	MajorName
)

VALUES
	('BUSTECH', 'Business Technology Major'),
	('SYSDEV', 'Systems Devlopment Major'),
	('INTMED', 'Interactive Media Major'),
	('NURS', 'Nursing') ;

Select * FROM Administrator

INSERT INTO Administrator(
	adminID,
	fName,
	mName,
	lName,
	clearanceLevel
)
Values
	('001', 'Lachlan', 'Geoffrey', 'Barden', '1'),
	('002', 'Kim', 'Anne', 'Hempsall', '1'),
	('003', 'Bohan', 'John', 'He', '1'),
	('004', 'Shenchong', 'Paul', 'Chen', '1') ;