import Announcement, {defaultOptions} from './Announcement';

export default Announcement;
export {defaultOptions};
